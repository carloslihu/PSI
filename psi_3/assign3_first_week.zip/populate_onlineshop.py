import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','onlineshop.settings')
import django
django.setup()
from shop.models import Category, Product
from random import randint
from django.core.files import File
from onlineshop.settings import MEDIA_ROOT
PRODUCT_IMAGES = os.path.join(os.path.join(MEDIA_ROOT, 'images'), 'products')

"""
from django.core.files import File
imageObject = File(open(os.path.join(directory_with_images, image_name),'r'))
p = Product.objects.get_or_create(category = ...,
prodName = ...,
...)[0]
p.image.save(image_name, imageObject, save = True)
"""

def populate():
	# First, we will create lists of dictionaries containing the pages
	# we want to add into each category.
	# Then we will create a dictionary of dictionaries for our categories.
	# This might seem a little bit confusing, but it allows us to iterate
	# through each data structure, and add the data to our models.
	cologne_products = [
	{"prodName":"Phantom Blood", "image":"PB.jpg", "description":"scent of inmortal vamipe lord", "price":1, "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Battle Tendency", "image":"BT.jpg", "description":"the feel of determination's power", "price":2, "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Stardust Crusaders", "image":"SC.jpg", "description":"the arome of Egypt", "price":3, "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Diamond Is Unbreakable", "image":"DIU.jpg", "description":"fragance of a crazy, noisy, bizarre town", "price":4, "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Vento Aureo", "image":"VA.jpg", "description":"smell of italian elegance", "price":5, "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Stone Ocean", "image":"SO.jpg", "description":"fragance of satisfactory revenge", "price":6, "stock":randint(1, 100), "availability":randint(0,1)}
	]

	parfum_products = [
	{"prodName":"Onett", "image":"onett.jpg", "description":"fragance of adventure", "price":3., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Twoson", "image":"twoson.jpg", "description":"feel of Autum", "price":3., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Threed", "image":"threed.jpg", "description":"Groovy Halloween-like", "price":3., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Fourside", "image":"fourside.jpg", "description":"elegant city-men feel", "price":3., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Winters", "image":"winters.jpg", "description":"cold as the peak of a mountain", "price":3., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Summers", "image":"summers.jpg", "description":"relaxing as holidays on a beach", "price":3., "stock":randint(1, 100), "availability":randint(0,1)} ]

	toilette_products = [
	{"prodName":"Symetra", "image":"symetra.jpg", "description":"fragance of order", "price":1., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Ana", "image":"ana.jpg", "description":"feel of home", "price":1., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Mercy", "image":"mercy.jpg", "description":"god complex fragance", "price":1., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Zarya", "image":"zarya.jpg", "description":"strong as the mountain", "price":1., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Mei", "image":"mei.jpg", "description":"freezing", "price":1., "stock":randint(1, 100), "availability":randint(0,1)},
	{"prodName":"Phara", "image":"phara.jpg", "description":"justice rains from above", "price":1., "stock":randint(1, 100), "availability":randint(0,1)} ]








	cats = {"Eau de Cologne": {"products":cologne_products},
	"Eau de Parfum": {"products":parfum_products},
	"Eau de Toilette": {"products":toilette_products} }
	# If you want to add more catergories or pages,
	#add them to the dictionaries above.
	#The code below goes through the cats dictionary, then adds each category,
	#and then adds all the associated pages for that category.
	#if you are using Python 2.x then use cats.iteritems() see
	#http://docs.quantifiedcode.com/python-anti-patterns/readability/
	#for more information about how to iterate over a dictionary properly.
	for cat, cat_data in cats.items():
		c = add_category(cat)
		for p in cat_data["products"]:
			add_product(c, p["prodName"], p["image"],p["description"],p["price"],p["stock"],p["availability"])
	# Print out the categories we have added.
	for c in Category.objects.all():
		for p in Product.objects.filter(category=c):
			print("- {0} - {1}".format(str(c), str(p)))

def add_product(category, prodName, image, description, price, stock, availability):
	imageObject = File(open(os.path.join(PRODUCT_IMAGES, image),'r'))
	p = Product.objects.get_or_create(category=category, prodName=prodName, price=price, description=description)[0]
	p.image =imageObject
	p.stock=stock
	p.availability = availability
	p.image.save(image, imageObject, save = True)
	p.save()
	return p

def add_category(name):
	c = Category.objects.get_or_create(catName=name)[0]
	c.save()
	return c

# Start execution here!
if __name__ == '__main__':
	print("Starting Shop population script...")
	populate()